//
//  Demo02_ViewBasedApplicationDemoViewController.m
//  Demo02_ViewBasedApplicationDemo
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "Demo02_ViewBasedApplicationDemoViewController.h"
#import "MyOtherViewControler.h"

@implementation Demo02_ViewBasedApplicationDemoViewController

-(IBAction) btnChangeToAnotherView_Click:(id)sender
{
    MyOtherViewControler *other =
    [[MyOtherViewControler alloc] init];
    
    // Animation
    [UIView beginAnimations:@"flipping view" context:nil];
    [UIView setAnimationDuration:1];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft
                           forView:self.view
                             cache:true];
    
    [self.view addSubview:other.view];
    
    [UIView commitAnimations];
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

//
//  Demo02_ViewBasedApplicationDemoViewController.h
//  Demo02_ViewBasedApplicationDemo
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo02_ViewBasedApplicationDemoViewController : UIViewController {
    
}

-(IBAction) btnChangeToAnotherView_Click : (id) sender;

@end

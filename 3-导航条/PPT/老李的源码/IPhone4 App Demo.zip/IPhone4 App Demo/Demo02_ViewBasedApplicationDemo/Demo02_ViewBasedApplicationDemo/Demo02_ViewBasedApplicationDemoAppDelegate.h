//
//  Demo02_ViewBasedApplicationDemoAppDelegate.h
//  Demo02_ViewBasedApplicationDemo
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Demo02_ViewBasedApplicationDemoViewController;

@interface Demo02_ViewBasedApplicationDemoAppDelegate : NSObject 
    <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet Demo02_ViewBasedApplicationDemoViewController *viewController;

@end

//
//  MyOtherViewControler.h
//  Demo02_ViewBasedApplicationDemo
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyOtherViewControler : UIViewController {
    
}

-(IBAction) btnClose: (id) sender;

@end

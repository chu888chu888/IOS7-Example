//
//  Demo02_ViewBaseAppDemoViewController.m
//  Demo02_ViewBaseAppDemo
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "Demo02_ViewBaseAppDemoViewController.h"
#import "MyChildViewControler.h"

@implementation Demo02_ViewBaseAppDemoViewController

- (void)dealloc
{
    [super dealloc];
}

-(IBAction) btnGotoChildView_Click:(id)sender
{
    // 定义要打开的视图控制器的对象并形成实例
    MyChildViewControler *childView = [[MyChildViewControler alloc] init];
    
    // 定义显示新视图的动画效果
    [UIView beginAnimations:@"flipping view" context:nil];
    // 动画的持续时间（秒）
    [UIView setAnimationDuration:1];
    // 动画效果的样式
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationTransition:UIViewAnimationTransitionCurlUp
                           forView:self.view
                             cache:true];
    
    // 显示要打开的视图
    [self.view addSubview:childView.view];
    
    // 提交动画，即开始执行
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

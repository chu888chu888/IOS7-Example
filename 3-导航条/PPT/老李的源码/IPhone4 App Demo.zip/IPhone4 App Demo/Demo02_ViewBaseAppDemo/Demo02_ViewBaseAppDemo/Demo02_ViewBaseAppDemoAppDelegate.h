//
//  Demo02_ViewBaseAppDemoAppDelegate.h
//  Demo02_ViewBaseAppDemo
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Demo02_ViewBaseAppDemoViewController;

@interface Demo02_ViewBaseAppDemoAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet Demo02_ViewBaseAppDemoViewController *viewController;

@end

//
//  Demo02_ViewBaseAppDemoViewController.h
//  Demo02_ViewBaseAppDemo
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo02_ViewBaseAppDemoViewController : UIViewController {
    
}

-(IBAction) btnGotoChildView_Click : (id) sender;

@end

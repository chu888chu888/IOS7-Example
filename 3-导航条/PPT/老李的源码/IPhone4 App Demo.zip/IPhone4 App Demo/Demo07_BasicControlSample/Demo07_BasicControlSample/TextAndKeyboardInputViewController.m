//
//  TextAndKeyboardInputViewController.m
//  Demo07_BasicControlSample
//
//  Created by LiHailong on 11-4-2.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "TextAndKeyboardInputViewController.h"


@implementation TextAndKeyboardInputViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(IBAction) btnReturn_Click:(id)sender{
    [self.view removeFromSuperview];
}

-(IBAction) txtMainTextField_DoneEdit:(id)sender{
    [sender resignFirstResponder];
}

-(IBAction) btnModifyKeyboard_Click:(id)sender {
    if ([txtMainTextField isFirstResponder]) {
        // 当前是打开状态
        
        // 关闭键盘
        [txtMainTextField resignFirstResponder];
        
        // 更改对应的按钮显示的文本
        [btnModifyKeyBoard setTitle: @"Open Keyboard"
                           forState:UIControlStateNormal] ;

        // 更改对应的Switch的状态
        [swcModifyKeyBoard setOn:FALSE];
    }
    else {
        [txtMainTextField becomeFirstResponder];
        
        [btnModifyKeyBoard setTitle: @"Close Keyboard"
                           forState:UIControlStateNormal] ;

        [swcModifyKeyBoard setOn:TRUE];

    }
}


- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

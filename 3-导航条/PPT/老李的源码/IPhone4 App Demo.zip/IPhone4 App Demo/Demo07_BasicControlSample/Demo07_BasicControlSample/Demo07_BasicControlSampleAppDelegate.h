//
//  Demo07_BasicControlSampleAppDelegate.h
//  Demo07_BasicControlSample
//
//  Created by LiHailong on 11-4-2.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Demo07_BasicControlSampleViewController;

@interface Demo07_BasicControlSampleAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet Demo07_BasicControlSampleViewController *viewController;

@end

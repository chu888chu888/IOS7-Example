//
//  TextFieldWithScrollViewController.h
//  Demo07_BasicControlSample
//
//  Created by LiHailong on 11-4-2.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TextFieldWithScrollViewController : UIViewController {
    
}

-(IBAction) btnReturn_Click : (id)sender;

@end

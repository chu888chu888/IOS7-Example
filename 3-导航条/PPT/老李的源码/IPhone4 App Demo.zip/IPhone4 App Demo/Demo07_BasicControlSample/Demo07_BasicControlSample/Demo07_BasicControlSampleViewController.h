//
//  Demo07_BasicControlSampleViewController.h
//  Demo07_BasicControlSample
//
//  Created by LiHailong on 11-4-2.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo07_BasicControlSampleViewController : UIViewController {
    
}

-(IBAction) btnNavToTextAndKeyboardInput_Click : (id)sender;
-(IBAction) btnNavToManyTextFieldInScrollView_Click : (id) sender;
@end

//
//  Demo07_BasicControlSampleViewController.m
//  Demo07_BasicControlSample
//
//  Created by LiHailong on 11-4-2.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "Demo07_BasicControlSampleViewController.h"

#import "TextAndKeyboardInputViewController.h"
#import "TextFieldWithScrollViewController.h"

@implementation Demo07_BasicControlSampleViewController

- (void)dealloc
{
    [super dealloc];
}

-(IBAction) btnNavToTextAndKeyboardInput_Click:(id)sender{
    TextAndKeyboardInputViewController *viewController =
        [[TextAndKeyboardInputViewController alloc] init];
    
    [self.view addSubview:viewController.view];
}

-(IBAction) btnNavToManyTextFieldInScrollView_Click:(id)sender {
    TextFieldWithScrollViewController *viewControllder =
        [[TextFieldWithScrollViewController alloc] init];
    
    [self.view addSubview:viewControllder.view];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

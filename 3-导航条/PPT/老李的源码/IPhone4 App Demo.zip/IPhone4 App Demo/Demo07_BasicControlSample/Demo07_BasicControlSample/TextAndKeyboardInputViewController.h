//
//  TextAndKeyboardInputViewController.h
//  Demo07_BasicControlSample
//
//  Created by LiHailong on 11-4-2.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TextAndKeyboardInputViewController : UIViewController {
    IBOutlet UITextField *txtMainTextField;
    IBOutlet UIButton *btnModifyKeyBoard;
    IBOutlet UISwitch *swcModifyKeyBoard;
}

-(IBAction) btnReturn_Click : (id) sender;

-(IBAction) txtMainTextField_DoneEdit : (id) sender;

-(IBAction) btnModifyKeyboard_Click : (id) sender;

@end

//
//  Demo03_WinBaseAppAppDelegate.h
//  Demo03_WinBaseApp
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyCustomView.h"

@interface Demo03_WinBaseAppAppDelegate : NSObject <UIApplicationDelegate> {

    MyCustomView * customViewControler;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MyCustomView *customViewControler;

@end

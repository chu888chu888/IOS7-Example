//
//  MyCustomView.h
//  Demo03_WinBaseApp
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyCustomView : UIViewController {
    
}

@end

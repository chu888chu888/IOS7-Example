//
//  Demo01_HelloIPhone4ViewController.h
//  Demo01_HelloIPhone4
//
//  Created by DHEE on 11-4-8.
//  Copyright 2011年 Dalian Hi-Think Computer Technology Corp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Demo01_HelloIPhone4ViewController : UIViewController  
    <UIAlertViewDelegate, UIActionSheetDelegate> 
{
    IBOutlet UITextField *txtMessage;
}

// 处理UIAlertView的Cancel按钮点击事件
-(void) alertViewCancel     :(UIAlertView *)alertView;

// 处理UIAlertView的所有按钮点击事件，定义此方法，可以省略上面的方法
-(void) alertView           :(UIAlertView *)alertView 
        clickedButtonAtIndex:(NSInteger)buttonIndex;

-(void) actionSheet         :(UIActionSheet *)actionSheet 
        clickedButtonAtIndex:(NSInteger)buttonIndex;

@property (nonatomic, retain) UITextField *txtMessage;

-(IBAction) btnShowText_Click : (id) sender;
-(IBAction) btnShowMessage_Click : (id) sender;
-(IBAction) btnGetMessage_Click : (id) sender;

-(IBAction) btnShowMultiAlertViewButton_Click : (id) sender;

-(IBAction) btnSHowActionSheet_Click : (id) sender;

@end

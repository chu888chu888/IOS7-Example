//
//  Demo01_HelloIPhone4AppDelegate.h
//  Demo01_HelloIPhone4
//
//  Created by DHEE on 11-4-8.
//  Copyright 2011年 Dalian Hi-Think Computer Technology Corp. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Demo01_HelloIPhone4ViewController;

@interface Demo01_HelloIPhone4AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet Demo01_HelloIPhone4ViewController *viewController;

@end

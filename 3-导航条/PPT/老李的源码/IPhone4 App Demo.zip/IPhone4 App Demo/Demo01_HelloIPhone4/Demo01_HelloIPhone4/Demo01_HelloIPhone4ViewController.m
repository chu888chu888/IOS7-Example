//
//  Demo01_HelloIPhone4ViewController.m
//  Demo01_HelloIPhone4
//
//  Created by DHEE on 11-4-8.
//  Copyright 2011年 Dalian Hi-Think Computer Technology Corp. All rights reserved.
//

#import "Demo01_HelloIPhone4ViewController.h"

@implementation Demo01_HelloIPhone4ViewController

@synthesize txtMessage;

- (void)dealloc
{
    [txtMessage release];
    [super dealloc];
}


-(IBAction) btnSHowActionSheet_Click:(id)sender {
    UIActionSheet *sheet =
        [[UIActionSheet alloc] initWithTitle:@"Action Sheet Title"
                                    delegate:self
                           cancelButtonTitle:@"Cancel"
                      destructiveButtonTitle:@"Destruct Button Title"
                           otherButtonTitles:@"Yes", @"No" , nil];
    [sheet showInView:self.view];
    [sheet release];
}

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *message;
    switch (buttonIndex) {
        case 0:
            message = @"Destruct Button";
            break;
        case 1:
            message = @"Yes";
            break;
        case 2:
            message = @"No";
            break;
        case 3:
            message = @"Cancel";
            break;
    }
    
    [txtMessage setText:message];
}

-(IBAction) btnShowText_Click:(id)sender
{
    [txtMessage setText:@"Hello IPhone4!"];
}

-(IBAction) btnShowMessage_Click:(id)sender
{
    UIAlertView *view = 
        [[UIAlertView alloc] initWithTitle:@"System Infomation"
                                   message:@"Hello IPhone4!!!"
                                  delegate:self
                         cancelButtonTitle:@"OK"
                         otherButtonTitles:nil];
    
    [view show];
    [view release];
}

-(void) btnGetMessage_Click:(id)sender
{
    NSString *message = [[NSString alloc] 
                         initWithFormat:@"Welcome %@ to IPhone4",
                         [txtMessage text] ];
    UIAlertView *view = 
    [[UIAlertView alloc] initWithTitle:@"System Infomation"
                               message:message
                              delegate:self
                     cancelButtonTitle:@"OK"
                     otherButtonTitles:nil, nil];
    
    [view show];
    [view release];
}


-(void) btnShowMultiAlertViewButton_Click:(id)sender
{
    // 定义并初始化UIAlertView对象
    UIAlertView *view = 
        [[UIAlertView alloc] initWithTitle:@"Multi Button Alert View"
                                   message:@"Please click Buttons"
                                  delegate:self
                         cancelButtonTitle:@"Cancel"
                         otherButtonTitles:@"Yes", @"No", nil];
    // 设置UIAlertView的Tag属性,供程序识别对象
    [view setTag:100];
        
    // 显示UIAlertView
    [view show];
    [view release];
}

-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    // 根据alertView参数判断是哪一个UIAlertView对象引发的事件
    if ([alertView tag] == 100){
        NSString *message;
        // 根据buttonIndex判断点击哪一个按钮
        switch (buttonIndex) {
            case 0:
                message = @"Cancel Button Click";
                break;
            case 1:
                message = @"Yes Button Click";
                break;
            case 2:
                message = @"No Button Click";
                break;
        }
    
        [txtMessage setText:message];
    }
}



- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

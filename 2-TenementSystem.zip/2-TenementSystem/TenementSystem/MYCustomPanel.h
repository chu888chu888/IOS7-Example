
#import "MYIntroductionPanel.h"

@interface MYCustomPanel : MYIntroductionPanel <UITextViewDelegate> {
    
    __weak IBOutlet UIView *CongratulationsView;
}


- (IBAction)didPressEnable:(id)sender;

@end



#import <UIKit/UIKit.h>
#import "MYBlurIntroductionView.h"

@interface MYViewController : UIViewController <MYIntroductionDelegate>

@end


#import "MYCustomPanel.h"
#import "MYBlurIntroductionView.h"

@implementation MYCustomPanel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


#pragma mark - Interaction Methods
-(void)panelDidAppear{
    NSLog(@"Panel Did Appear");
    
   [self.parentIntroductionView setEnabled:NO];
}

-(void)panelDidDisappear{
    NSLog(@"Panel Did Disappear");
    CongratulationsView.alpha = 0;
}
#pragma mark Outlets
- (IBAction)didPressEnable:(id)sender {
    [UIView animateWithDuration:0.3 animations:^{
        CongratulationsView.alpha = 1;
    }];
    
    [self.parentIntroductionView setEnabled:YES];
}


@end

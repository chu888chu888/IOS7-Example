//
//  main.m
//  Demo07_IOSample
//
//  Created by DHEE on 11-4-8.
//  Copyright 2011年 Dalian Hi-Think Computer Technology Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FileSystemManager.h"

int main (int argc, const char * argv[])
{

    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    [FileSystemManager NSFileManagerDemo1];
    
    [FileSystemManager PathUtilitiesDemo];

    [pool drain];
    return 0;
}


//
//  FileSystemManager.h
//  Demo07_IOSample
//
//  Created by DHEE on 11-4-8.
//  Copyright 2011年 Dalian Hi-Think Computer Technology Corp. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FileSystemManager : NSObject {
    
}

+(void) NSFileManagerDemo1;

+(void) PathUtilitiesDemo;

@end

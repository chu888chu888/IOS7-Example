//
//  FileSystemManager.m
//  Demo07_IOSample
//
//  Created by DHEE on 11-4-8.
//  Copyright 2011年 Dalian Hi-Think Computer Technology Corp. All rights reserved.
//

#import "FileSystemManager.h"


@implementation FileSystemManager

+(void) NSFileManagerDemo1
{
    NSFileManager *fm = [NSFileManager defaultManager];
    NSLog(@"%@",[fm currentDirectoryPath]);
    [fm changeCurrentDirectoryPath:@"/Users/dhee/Documents"];
    NSLog(@"%@",[fm currentDirectoryPath]);

    // 枚举当前目录的所有文件及子目录，不包含子目录中的文件及目录
    NSArray *items = [fm directoryContentsAtPath:[fm currentDirectoryPath]];
    for (NSString *it in items){
        NSLog(@"%@",it);
    }
    
    // 枚举当前目录的所有文件及子目录，包含子目录中的文件及目录
    NSDirectoryEnumerator *dirs = [fm enumeratorAtPath: [fm currentDirectoryPath]];
    while (true) {
        NSString *item = [dirs nextObject];
        if (item == nil) {
            break;
        }
        
        //NSLog(@"%@",item);
    }
}

+(void) PathUtilitiesDemo{
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm changeCurrentDirectoryPath:@"~/Documents/main.m"];
    NSLog(@"Current Directory is %@",[fm currentDirectoryPath]);
    
    // lastPathComponent如果对应一个目录，返回的是这个目录的名
    //                  如果对应一个文件，返回的是这个文件的名
    NSString *lastPathComponent = [@"~/Documents/main.m" lastPathComponent];
    NSLog(@"lastPathComponent is %@",lastPathComponent);
    
    lastPathComponent = [@"~/Documents" pathExtension];
    NSLog(@"lastPathComponent is %@",lastPathComponent);
    
    NSString *userName = NSFullUserName();
    NSLog(@"%@",userName);
}

@end

//
//  Vector2.h
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Vector2 : NSObject {
    int x;
    int y;
}

@property int x;
@property int y;

-(Vector2 *) initWithXY : (int) xValue : (int) yValue;
-(void) print;

@end

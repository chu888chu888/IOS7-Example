//
//  VectorOpt.m
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "VectorOpt.h"

@implementation Vector2 (VectorOpt)

-(Vector2 *) Add:(Vector2 *)other
{
    int resX = x + other.x;
    int resY = y + other.y;
    
    Vector2 *res = [[Vector2 alloc] initWithXY:resX :resY];
    return res;
}

-(Vector2 *) Sub:(Vector2 *)other
{
    int resX = x - other.x;
    int resY = y - other.y;
    
    Vector2 *res = [[Vector2 alloc] initWithXY:resX :resY];
    return res;
}

@end

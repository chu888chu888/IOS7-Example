//
//  VectorOpt.h
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Vector2.h"

@interface Vector2 (VectorOpt)

// 附加二维向量的加法和减法运算
-(Vector2 *) Add : (Vector2 *) other;
-(Vector2 *) Sub : (Vector2 *) other;

@end

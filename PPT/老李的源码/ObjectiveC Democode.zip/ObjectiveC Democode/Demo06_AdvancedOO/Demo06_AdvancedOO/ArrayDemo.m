//
//  ArrayDemo.m
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "ArrayDemo.h"
#import <Foundation/Foundation.h>

@implementation ArrayDemo


+(void) CArrayDemo1
{
    // 定义并使用一维数组计算1〜100的和
    int items[100];
    for (int i = 0; i < 100; i++) 
    {
        items[i] = i + 1;
    }
    
    int sum = 0;
    for (int i = 0; i < 100; i++) 
    {
        sum += items[i];
    }
    NSLog(@"1+2+3+...+100=%i",sum);
    
}

+(void) CArrayDemo2
{
    // 使用多维数组打印扬辉三角
    int yh[10][10];
    
    for (int i = 0; i < 10; i++) 
    {
        yh[i][0] = 1;
        yh[i][i] = 1;
        for (int j = 1; j < i; j++) 
        {            
            yh[i][j] = yh[i-1][j-1] + yh[i-1][j];
        }
    }
    
    for (int i = 0; i < 10; i++) 
    {
        for (int j = 0; j <= i; j++) 
        {
            printf("%i\t",yh[i][j]);
        }
        printf("\n");
    }
}

+(void) CArrayDemo3
{
    // 使用多维数组打印乘法表
    NSString *str[9][9];
    for (int i = 0; i < 9; i++) 
    {
        for (int j = 0; j <= i; j++) 
        {
            str[i][j] = [[NSString alloc] 
                         initWithFormat:@"%i*%i=%i",j+1,i+1,(i+1)*(j+1)];
        }
    }
    
    for (int i = 0; i < 9; i++) 
    {
        for (int j = 0; j <= i; j++) 
        {
            printf("%s\t",[str[i][j] UTF8String]);
        }
        printf("\n");
    }
    
}


+(void) NSArrayDemo1
{
    NSString *s1 = @"AAA";
    NSString *s2 = @"BBB";
    
    NSArray *array = [[NSArray alloc] initWithObjects:
                      s1,s2, nil];
    
    // for循环遍历数组元素
    for (int i = 0; i < 2; i++) 
    {
        NSLog(@"%@",[array objectAtIndex:i]);
    }
    
    // for...in循环遍历数组元素
    for(NSString *item in array)
    {
        NSLog(@"%@",item);
    }
}

+(void) NSArrayDemo2 {
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:100];
    
    for (int i = 2; i <= 1000; i++) {
        _Bool exist = false;
        for (int j = 2; j <= sqrt(i); j++) {
            if (i % j == 0) {
                exist = true;
                break;
            }
        }
        
        if (exist == false) {
            [array addObject:[NSNumber numberWithInt:i]];
        }
    }    
    
    for (int i = 0; i < [array count]; i++) {
        printf("%i\t",[[array objectAtIndex:i] intValue]);
    }
}


+(void) NSArrayDemo3 {
    NSMutableArray * cfb = [[NSMutableArray alloc] initWithCapacity:9];
    
    for (int row = 0; row < 9; row++) {
        NSMutableArray *rowItems = [[NSMutableArray alloc] initWithCapacity:row + 1];
        
        for (int itemIndex = 0; itemIndex <= row; itemIndex++) {
            NSString *item =
                [[NSString alloc] initWithFormat:
                 @"%i*%i=%i",itemIndex+1,row+1,(itemIndex+1)*(row+1)];
            
            [rowItems addObject:item];
        }
        
        [cfb addObject:rowItems];
    }
    
    for (NSMutableArray *row in cfb){
        for (NSString *item in row) {
            printf("%s\t",[item UTF8String]);
        }
        printf("\n");
    }
}


+(void) NSStringDemo1
{
    //while (true) {
    printf("Please input a email address:");
    char input[50];
    scanf("%s",input);
        
    NSString *email = [[NSString alloc] initWithUTF8String:input];
        
        if ([email characterAtIndex:0] == '@') {
            NSLog(@"wrong");
        }
           
        for (int i = 0; i < [email length]; i++) {
        char c = [email characterAtIndex:i];
        
        // 遍历字符串中的每一个字符
        printf("%c\t",c);
    }
    
}


+(void) DictionaryDemo
{
    NSArray *key = [[NSArray alloc] initWithObjects:@"A",@"B",@"C", nil];
    NSArray *value = [[NSArray alloc] initWithObjects:@"AAA",@"BBB",@"CCC", nil];
    
    
    NSDictionary *dic = [[NSDictionary alloc] initWithObjects:key forKeys:value];
    
//    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:5];
//    [dic setObject:@"AAAA" forKey:@"A"];
    
    
    for (NSString *k in dic) {
        NSString *v = [dic objectForKey:k];
        
        NSLog(@"%@   %@",v,k);
    }
}


+(void) SetDemo{
    NSMutableSet *set = [[NSMutableSet alloc] init];
    
    [set addObject:@"A"];
    [set addObject:@"B"];
    [set addObject:@"C"];
    [set addObject:@"A"];
    
    for (NSString *item in set){
        NSLog(@"%@",item);
    }
    
    
    //NSLog(@"%@",set);
}


+(void) NSArraySort{
    
    NSMutableArray * intArrays = [[NSMutableArray alloc] initWithCapacity:10];
    
    for (int i = 0; i < 10; i++) {
        NSNumber *number = [[NSNumber alloc] initWithLong:random()];
        
        [intArrays addObject:number];
    }
    
    //[intArrays sortUsingDescriptors:intArrays];
    //[intArrays sortUsingComparator:
        
    for (NSNumber *num in intArrays){
        NSLog(@"%i",[num intValue]);
    }
}

@end

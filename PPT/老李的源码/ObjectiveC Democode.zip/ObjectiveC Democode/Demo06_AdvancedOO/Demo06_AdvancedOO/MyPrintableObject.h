//
//  MyPrintableObject.h
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MyPrintableObject <NSObject>
-(void) print;
@end

//
//  NSNumberDemo.m
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "NSNumberDemo.h"


@implementation NSNumberDemo

+(void) Demo
{
    NSNumber *number = [[NSNumber alloc] initWithInt:10];
    NSLog(@"%@", number);
    
    NSString *str = @"Hello World";
    NSLog(@"%@",str);
}

@end

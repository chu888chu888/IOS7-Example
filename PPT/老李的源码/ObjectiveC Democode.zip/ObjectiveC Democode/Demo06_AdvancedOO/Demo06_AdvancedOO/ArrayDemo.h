//
//  ArrayDemo.h
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ArrayDemo : NSObject {
    
}

+(void) CArrayDemo1;
+(void) CArrayDemo2;
+(void) CArrayDemo3;


+(void) NSArrayDemo1;
+(void) NSArrayDemo2;
+(void) NSArrayDemo3;

+(void) NSStringDemo1;


+(void) DictionaryDemo;
+(void) SetDemo;

+(void) NSArraySort;

@end

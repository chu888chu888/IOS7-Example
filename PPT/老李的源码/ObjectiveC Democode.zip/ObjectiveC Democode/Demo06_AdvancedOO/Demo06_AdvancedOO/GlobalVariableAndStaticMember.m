//
//  GlobalVariableAndStaticMember.m
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "GlobalVariableAndStaticMember.h"

static int gMyGlobalStaticVariable = 0;

@implementation GlobalVariableAndStaticMember

-(void) setGlobalVariableValue:(int)newValue
{
    extern int gMyGlobalVariable;
    
    NSLog(@"In Method globalVariable init value is %i\n",gMyGlobalVariable);
    
    gMyGlobalVariable = newValue;
    
    NSLog(@"In Method set globalVariable is %i\n",gMyGlobalVariable);
}

+(void) setGlobalStaticVariableValue:(int)newValue
{
    
    extern int gMyGlobalStaticVariable;
    gMyGlobalStaticVariable = newValue;
    
    NSLog(@"In Static Method set staticGlobalVariable is %i\n",newValue);
    
}

@end

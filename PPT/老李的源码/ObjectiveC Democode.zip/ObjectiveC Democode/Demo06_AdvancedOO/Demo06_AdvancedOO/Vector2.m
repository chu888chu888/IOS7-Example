//
//  Vector2.m
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "Vector2.h"


@implementation Vector2

@synthesize x;
@synthesize y;

-(Vector2 *) initWithXY:(int)xValue :(int)yValue
{
    self = [super init];
    
    if (self)
    {
        x = xValue;
        y = yValue;
    }
    
    return self;
}

-(void) print
{
    NSLog(@"(%i,%i)",x,y);
}

@end

//
//  main.m
//  Demo06_AdvancedOO
//
//  Created by DHEE on 11-4-7.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GlobalVariableAndStaticMember.h"
#import "Vector2.h"
#import "VectorOpt.h"
#import "NSNumberDemo.h"

#import "ArrayDemo.h"

int gMyGlobalVariable = 0;

enum DayOfWeek
{
    Sun,
    Mon,
    Tue,
    Wed,
    Thu,
    Fri,
    Sta,
};


int main (int argc, const char * argv[])
{

    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    /*
    GlobalVariableAndStaticMember *instanceA =
    [[GlobalVariableAndStaticMember alloc] init];
    
    GlobalVariableAndStaticMember *instanceB =
    [[GlobalVariableAndStaticMember alloc] init];
    
    [instanceA setGlobalVariableValue:100];
    NSLog(@"In main globalVariable value is %i\n",gMyGlobalVariable);
    
    [instanceB setGlobalVariableValue:200];
    NSLog(@"In main globalVariable value is %i\n",gMyGlobalVariable);
    
    [instanceA release];
    [instanceB release];
    
    [GlobalVariableAndStaticMember setGlobalStaticVariableValue:300];
    //NSLog(@"In main staticGlobalVariable value is %i\n",gMyGlobalStaticVariable);
     
    
    
    enum DayOfWeek week = Mon;
    NSLog(@"%i",week);
    
    int weekValue;
    scanf("%i",weekValue);
    enum DayOfWeek week2 = (enum DayOfWeek)weekValue;
    NSLog(@"%i",week2);
        
    Vector2 *v1 = [[Vector2 alloc] initWithXY:4 :5];
    Vector2 *v2 = [[Vector2 alloc] initWithXY:2 :3];
    
    [v1 print];
    [v2 print];
    
    Vector2 *v3 = [v1 Add:v2];
    Vector2 *v4 = [v1 Sub:v2];
    
    [v3 print];
    [v4 print];
    
    [v1 release];
    [v2 release];
    [v3 release];
    [v4 release];
    
    [NSNumberDemo Demo];
     */

    //[ArrayDemo CArrayDemo1];
    //[ArrayDemo NSArrayDemo3];
    //[ArrayDemo NSStringDemo1];
    //[ArrayDemo DictionaryDemo];
    [ArrayDemo SetDemo];
    
    //[ArrayDemo NSArraySort];
    
    [pool drain];
    return 0;
}


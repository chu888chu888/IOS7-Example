//
//  StaticMemberClass.m
//  Demo05_BasicClassExtends
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "StaticMemberClass.h"


@implementation StaticMemberClass

+(void) staticMethod
{
    NSLog(@"StaticMemberClass Static Method\n");
}

-(void) instanceMethod
{

}

@end

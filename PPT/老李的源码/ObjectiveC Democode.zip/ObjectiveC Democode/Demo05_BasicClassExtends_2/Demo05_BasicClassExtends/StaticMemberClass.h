//
//  StaticMemberClass.h
//  Demo05_BasicClassExtends
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StaticMemberClass : NSObject {
    
}

+(void) staticMethod;

-(void) instanceMethod;

@end

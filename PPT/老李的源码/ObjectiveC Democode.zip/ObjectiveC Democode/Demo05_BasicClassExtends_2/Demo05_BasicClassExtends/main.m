//
//  main.m
//  Demo05_BasicClassExtends
//
//  Created by DHEE on 11-4-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyClassA.h"
#import "MyClassB.h"
#import "MyClassC.h"

#import "MyClassX.h"
#import "MyClassY.h"

#import "MyVector2.h"

#import "SampleClass.h"

#import "StaticMemberClass.h"


int gMyGlobleMember = 100;


void showGlobleMemberValue ()
{
    //NSLog(@"%i",gMyGlobleMemberVariable);

    //printf("Hello");

    NSLog(@"Hello");
}


int main (int argc, const char * argv[])
{

    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    MyClassA *ca = [[MyClassA alloc] init];
    MyClassB *cb = [[MyClassB alloc] init];
    
    ca.parentClassMember = 1;
    [ca parentClassMember];
    NSLog(@"%i\n",ca.parentClassMember);
    [ca parentMethod];
    
    NSLog(@"\n");
    
    cb.parentClassMember = 100;
    cb.childClassMember = 200;
    NSLog(@"%i\n",cb.parentClassMember);
    NSLog(@"%i\n",cb.childClassMember);
    [cb childClassMethod];
    [cb parentMethod];
    [cb parentMethod:123];

    [ca release];
    [cb release];
    
    
    
    MyClassA *cab = [[MyClassB alloc] init];
    [cab parentMethod];
    [cab release];
    
    MyClassA *cac = [[MyClassC alloc] init];
    [cac parentMethod];
    [cac release];
    
    /*
    id *objA = [[MyClassX alloc] init];
    [objA printVar];
    [objA release];
    
    id *objB = [[MyClassY alloc] init];
    [objB printVar];
    [objB release];
    */
    
    
    MyVector2 *v1 = [[MyVector2 alloc] init];
    v1.x = 1;
    v1.y = 2;
    [v1 printVector];
    [v1 release];
    
    MyVector2 *v2 = [[MyVector2 alloc] initWithXY:100 :200];
    [v2 printVector];
    [v2 release];
    
    
    SampleClass *sc = [[SampleClass alloc] init];
    
    sc->publicMember = 1;
    NSLog(@"%i\n",sc->publicMember);
    
    // sc->privateMember = 3;
        
    [sc release];
    
    showGlobleMemberValue();
    
    [StaticMemberClass staticMethod];
    
    
    [pool drain];
    return 0;
}



//
//  SampleClass.h
//  Demo05_BasicClassExtends
//
//  Created by DHEE on 11-4-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SampleClass : NSObject {

@private
    int privateMember;
    int anotherPrivateMember;
    
@protected
    int protectedMember;

@public
    int publicMember;
}

@end

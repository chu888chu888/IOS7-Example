//
//  MyClassB.m
//  Demo05_BasicClassExtends
//
//  Created by DHEE on 11-4-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MyClassB.h"


@implementation MyClassB

@synthesize childClassMember;

-(void) childClassMethod
{
    NSLog(@"Child class method\n");
}

-(void) parentMethod
{
    NSLog(@"MyClass B override Parent Class Method");
}

-(void) parentMethod:(int)param
{
    NSLog(@"Child class overload parent method with parameter %i",param);
}

@end

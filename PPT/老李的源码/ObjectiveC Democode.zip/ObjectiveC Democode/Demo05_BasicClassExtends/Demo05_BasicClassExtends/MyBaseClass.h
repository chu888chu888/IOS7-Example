//
//  MyBaseClass.h
//  Demo05_BasicClassExtends
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MyBaseClass : NSObject {
    int baseClassMember;
}

@property int baseClassMember;

-(void) baseClassMethod;

@end

//
//  MyVector2.h
//  Demo05_BasicClassExtends
//
//  Created by DHEE on 11-4-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MyVector2 : NSObject {
    int x;
    int y;    
}

@property int x;
@property int y;

// 带参数的初始化方法的声明
-(MyVector2 *) initWithXY: (int) x: (int) y;

-(void) printVector;

@end

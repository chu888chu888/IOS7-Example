//
//  MyChildClass.h
//  Demo05_BasicClassExtends
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyBaseClass.h"

@interface MyChildClass : MyBaseClass {
    int childClassMember;
}

@property int childClassMember;

-(void) childClassMethod;

@end

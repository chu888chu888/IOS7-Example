//
//  MyChildClass.m
//  Demo05_BasicClassExtends
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MyChildClass.h"


@implementation MyChildClass

@synthesize childClassMember;

-(void) childClassMethod
{
    NSLog(@"MyChild Class ChildMethod");
}

@end

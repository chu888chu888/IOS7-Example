//
//  MyVector2.m
//  Demo05_BasicClassExtends
//
//  Created by DHEE on 11-4-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MyVector2.h"

@implementation MyVector2

@synthesize x;
@synthesize y;

-(void) printVector
{
    NSLog(@"(%i,%i)",x,y);
}

-(MyVector2 *) initWithXY:(int)initX :(int)initY
{
    self = [super init];
    
    if(self)
    {
        [self setX:initX];
        [self setY:initY];
    }
    
    return self;
}

@end

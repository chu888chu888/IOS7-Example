//
//  MyClassX.m
//  Demo05_BasicClassExtends
//
//  Created by DHEE on 11-4-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MyClassX.h"


@implementation MyClassX

-(void) printVar
{
    NSLog(@"MyClass X printVar method\n");
}

@end

//
//  MyClassA.m
//  Demo05_BasicClassExtends
//
//  Created by DHEE on 11-4-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MyClassA.h"


@implementation MyClassA

@synthesize parentClassMember;

-(void) parentMethod
{
    NSLog(@"Parent class method\n");
}

@end

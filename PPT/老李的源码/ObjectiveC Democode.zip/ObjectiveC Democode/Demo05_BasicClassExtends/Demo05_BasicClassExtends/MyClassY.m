//
//  MyClassY.m
//  Demo05_BasicClassExtends
//
//  Created by DHEE on 11-4-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MyClassY.h"

@implementation MyClassY

-(void) printVar
{
    NSLog(@"MyClass Y printVar method\n");
}

@end

//
//  main.m
//  Demo03_BasicStatement
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    // insert code here...
    // NSLog(@"Hello, World!");
    
    
    
    
    // 使用while循环计算1到100的和
    int number1 = 1;
    int sum1 = 0;
    while(number1 <= 100)
    {
        sum1 += number1;
        number1++;
    }
    printf("%i \n",sum1);
    
    
    // 使用for循环计算1到100的和
    int sum2 = 0;
    for(int i = 1 ; i <= 100 ; i++)
    {
        sum2 += i;
    }
    printf("%i \n",sum2);
    
    
    // 打印乘法表
    for(int i = 1 ; i <= 9 ; i++)
    {
        for(int j = 1 ; j <= i ; j++)
        {
            int res = i * j;
            printf("%i*%i=%i\t",j,i,res);
        }
        printf("\n");
    }
    
    
    //
    for(int i = 1 ; i <= 10 ; i++)
    {
        if(i == 5)
        {
            break;
        }
        
        printf("%i\t",i);
    }
    printf("\n");
    
    for(int i = 1 ; i <= 10 ; i++)
    {
        if(i == 5)
        {
            continue;
        }
        
        printf("%i\t",i);
    }
    printf("\n");
    
       
    
    
    // 年月日判断
    
    // 处理年份的输入
    printf("Please input year:");
    int year;
    scanf("%i",&year);
    
    // 处理月份的输入
    printf("Please input month:");
    int month;
    scanf("%i",&month);
    
    // 判断输入的年份是否为闰年
    /*
     _Bool isLeapYear;
    
    if(year % 100 == 0)
    {
        if(year % 400 == 0)
        {
            isLeapYear = true;
        }
        else
        {
            isLeapYear = false;
        }
    }
    else
    {
        if(year % 4 == 0)
        {
            isLeapYear = true;
        }
        else
        {
            isLeapYear = false;
        }
    }
    */
    
    _Bool isLeapYear = false;
    if((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0))
    {
        isLeapYear = true;
    }
    
    
    
    // NSLog(@"%i年是%@",year,isLeapYear?@"闰年":@"平年");
    
    // 计算输入的年份、月份共有多少天
    int days=0;
    switch(month)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            days = 31;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            days = 30;
            break;
        case 2:
            days = isLeapYear?29:28;
            break;
        default:
            days = -1;
            break;
    }
    
    // 打印结果
    printf("%i年%i月共有%i天",year,month,days);
    
    [pool drain];
    return 0;
}


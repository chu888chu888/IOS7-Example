//
//  main.m
//  Demo01_HelloObjectiveC
//
//  Created by LiHailong on 11-3-31.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    
    /*
     这是块注释，在示例显示最基本的Xcode应用程序结构
     */
    
    
    // 这是行注释，
    NSLog(@"Hello, Xcode!");    // 以Log的方式显示“Hello, Xcode!”
    
    
    // 在控制台中输出“Hello, Xcode!”
    printf("Hello, Xcode!\n");
    
    
    // 控制台格式化输出
    int i = 1;
    int j = 2;
    int sum = i + j;
    
    printf("%i + %i = %i" , i , j, sum);  // 控制台输出的结果为：“1＋2＝3”
    
    
    [pool drain];
    return 0;
}


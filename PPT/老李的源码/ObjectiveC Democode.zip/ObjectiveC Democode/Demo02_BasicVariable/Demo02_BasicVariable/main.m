//
//  main.m
//  Demo02_BasicVariable
//
//  Created by LiHailong on 11-3-31.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{

    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    // 变量及基本数据类型示例
    
    // 基本类型变量的声明及赋值
    int variable1;          // 变量的声明
    variable1 = 100;        // 变量的赋值
    
    int variable2 = 200;    // 在变量声明的同时赋值
    
    printf("variable1 value is %i;variable2 value is %i\n",
           variable1,variable2);
    
    
    // 整数
    int intBase10 = 100;    // 10进制值100
    int intBase8 = 037;     // 8进制值37
    int intBase16 = 0x3C;   // 16进制值3Ｃ
    
    printf("10进制值为：%i；8进制值为：%o；16进制值为：%x。\n",intBase10,intBase10,intBase10);
    printf("10进制值为：%i；8进制值为：%o；16进制值为：%x。\n",intBase8,intBase8,intBase8);
    printf("10进制值为：%i；8进制值为：%o；16进制值为：%x。\n",intBase16,intBase16,intBase16);
    
    // 浮点数
    float floatVariable = 123.456f;
    double doubleVariable = 0x1p10;
    
    printf("floatVariable value is %f ; doubleVariable value is %f \n",floatVariable,doubleVariable);
    printf("floatVariable value is %e ; doubleVariable value is %e \n",floatVariable,doubleVariable);
    printf("floatVariable value is %g ; doubleVariable value is %g \n",floatVariable,doubleVariable);
    printf("floatVariable value is %a ; doubleVariable value is %a \n",floatVariable,doubleVariable);

    // 字符型
    char charVariable = 'A';
    printf("charVariable value is %c \n",charVariable);
    
    printf("\n");
    
    // 基本数据类型转换
    float basicFloatValue = 12.34f;
    int conventIntValue = (int)basicFloatValue;
    printf("%i\n",conventIntValue);
    
    printf("\n");
    
    // int类型与char类型间的编码转换
    int intValue = 65;
    char charValue = (char)intValue;
    printf("intValue %i convert to charValue is %c \n",intValue,charValue);
    
    char charValue2 = 'A';
    int intValue2 = (int)charValue2;
    printf("charValue %c convert to intValue is %i \n",charValue2,intValue2);
    
    printf("\n");
    
    // 表达式
    int i=5;
    int j=2;
    double result = i/j;
    printf("%i/%i=%f\n",i,j,result);
    
    i++;
    
    
    
    [pool drain];
    return 0;
}

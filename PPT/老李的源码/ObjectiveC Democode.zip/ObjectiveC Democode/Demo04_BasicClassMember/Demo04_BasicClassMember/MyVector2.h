//
//  MyVector2.h
//  Demo04_BasicClassMember
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

// 定义一个描述二维向量的类型
@interface MyVector2 : NSObject {
    double x;
    double y;
}

@property double x; // 二维向量的Ｘ值
@property double y; // 二维向量的Ｙ值

-(void) print;

@end

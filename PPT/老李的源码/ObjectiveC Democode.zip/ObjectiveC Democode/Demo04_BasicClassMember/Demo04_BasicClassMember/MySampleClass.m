//
//  MySampleClass.m
//  Demo04_BasicClassMember
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MySampleClass.h"
#import "MyVector2.h"

@implementation MySampleClass

int privateVariable;

// 在类中同步属性
@synthesize fieldMemberA;

// 在类中方法的实现
// 赋值方法
-(void) setFieldMemberB:(int)value
{
    fieldMemberB = value;
}
// 取值方法
-(int) getFieldMemberB
{
    return fieldMemberB;
}



// 多参数方法的实现
-(void) multiParameterMethodA:(int)param1 
                             :(int)param2 
                             :(int)param3
{
    NSLog(@"param1 %i; param2 %i; param3 %i",param1,param2,param3);
}
-(void) multiParameterMethodB:(int)param1 
                 MethodParam2:(int)param2 
                 MethodParam3:(int)param3
{
    NSLog(@"param1 %i; param2 %i; param3 %i",param1,param2,param3);
}


-(void) testVariable
{
    int variableCount = 0;
    static int staticVariableCount = 0;
    
    instanceVariableCount++;    // instanceVariableCount被声明为类的实例成员变量
    variableCount++;            // variableCount被声明为此方法的局部变量
    staticVariableCount++;      // staticVariableCount被声明为此方法的局部静态变量
    
    printf("\nInstanceVariableCount %i ; VariableCount %i ; StaticVariableCount %i\n",
          instanceVariableCount,variableCount,staticVariableCount);
}


-(void) privateMethod
{
    NSLog(@"Called Private Method");
}

-(void) SampleMethodA
{
    NSLog(@"Called SampleMethodA");
    
    [self privateMethod];
    
    NSLog(@"Called SampleMethodA Completed");
}

-(void) SampleMethodB
{
    privateVariable = 1;
    
    NSLog(@"%i",privateVariable);
}


// 实现以对象做为参数及返回类型的方法
// 实现两个二维向量的加法
-(MyVector2 *) Add:(MyVector2 *)v1 :(MyVector2 *)v2
{
    int x = v1.x + v2.x;
    int y = v1.y + v2.y;
    
    MyVector2 *result = [[MyVector2 alloc] init];
    result.x = x;
    result.y = y;
    
    return result;
}

@end

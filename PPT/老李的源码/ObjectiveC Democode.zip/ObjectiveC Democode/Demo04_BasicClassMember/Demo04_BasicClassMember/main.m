//
//  main.m
//  Demo04_BasicClassMember
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MySampleClass.h"
#import "MyVector2.h"

int main (int argc, const char * argv[])
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    /*
    // 对象的声明
    MySampleClass *msc;
    // 为对象开辟实例空间
    msc = [MySampleClass alloc];
    // 初始化实例成员
    msc = [msc init];
        
    // 对象的声明
    MySampleClass *msc;
    // 对象开辟实例空间并同时初始化成员
    msc = [[MySampleClass alloc] init];
     */

    // 对象的声明、开辟实例空间及初始化成员放在同一条语句中
    MySampleClass *msc = [[MySampleClass alloc] init];
    
    
    // 调用属性为成员变量赋值
    msc.fieldMemberA = 100;
    
    // 调用属性对成员变量取值
    int faValue = msc.fieldMemberA;
    
    // 调用自动生成的属性的set访问器对变量赋值
    [msc setFieldMemberA:150];
    
    // 调用自动生成的属性的get访问器对变量取值
    int faValue2 = [msc fieldMemberA];
    
    // 调用方法为成员变量赋值
    [msc setFieldMemberB:200];
    
    // 调用方法对成员变量取值
    int fbValue = [msc getFieldMemberB];
    
    printf("%i %i %i",faValue,faValue2,fbValue);
    
    
    // 多参数的方法调用
    [msc multiParameterMethodA:1 
                              :2 
                              :3 ];
    
    [msc multiParameterMethodB:10 
                  MethodParam2:20 
                  MethodParam3:30];
    
    
    MyVector2 *v1 = [[MyVector2 alloc] init];
    v1.x = 1;
    v1.y = 2;
    MyVector2 *v2 = [[MyVector2 alloc] init];
    v2.x = 3;
    v2.y = 4;
    
    MyVector2 *v3 = [msc Add:v1 :v2 ];
    [v3 print];
    
    [v1 release];
    [v2 release];
    [v3 release];
    
    
    [msc SampleMethodA];
    [msc SampleMethodB];
    
        
    
    // 注销对象使用的资源
    [msc release];
    
    
    
    MySampleClass *msc1 = [[MySampleClass alloc] init];
    MySampleClass *msc2 = [[MySampleClass alloc] init];
    
    [msc1 testVariable];
    [msc1 testVariable];
    [msc2 testVariable];
    
    [msc1 release];
    [msc2 release];
    
        
    [pool drain];
    return 0;
}


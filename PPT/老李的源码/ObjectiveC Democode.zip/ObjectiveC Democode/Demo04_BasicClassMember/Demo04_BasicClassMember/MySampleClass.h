//
//  MySampleClass.h
//  Demo04_BasicClassMember
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyVector2.h"

@interface MySampleClass : NSObject {
    // 定义类中的成员变量
    
    int fieldMemberA;
    int fieldMemberB;
    
    
    // 实例成员变量
    int instanceVariableCount;
}

// 定义属性封装fieldMemberA的读写
@property int fieldMemberA;


// 定义方法封装fieldMemberB的读写
// 没有返回值的，带一个参数的方法，封装赋值过程
-(void) setFieldMemberB : (int) value;
// 有返回值，没有参数的方法，封装取值过程
-(int)  getFieldMemberB;

// 多参数的方法定义
// 第一种方式定义
-(void) multiParameterMethodA : (int) param1 
                              : (int) param2 
                              : (int) param3;
// 第二种方式定义
-(void) multiParameterMethodB : (int) param1 
                 MethodParam2 : (int) param2
                 MethodParam3 : (int) param3;


// 处理实例变量、局部变量、局部静态变量的方法
-(void) testVariable;

-(void) SampleMethodA;
-(void) SampleMethodB;



// 将对象类型作为方法的参数及返回
-(MyVector2 *) Add : (MyVector2 *) v1 : (MyVector2 *) v2;

@end

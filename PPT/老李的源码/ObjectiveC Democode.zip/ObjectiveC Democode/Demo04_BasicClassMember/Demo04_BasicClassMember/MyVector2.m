//
//  MyVector2.m
//  Demo04_BasicClassMember
//
//  Created by LiHailong on 11-4-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "MyVector2.h"

@implementation MyVector2

@synthesize x;
@synthesize y;

-(void) print
{
    NSLog(@"(%g,%g)",x,y);
}

@end

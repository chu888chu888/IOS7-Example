//
//  main.m
//  SimpleTable3
//
//  Created by Rickie Li on 12-10-11.
//  Copyright (c) 2012年 EntLib.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SimpleTableAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SimpleTableAppDelegate class]));
    }
}

//
//  SimpleTableViewController.h
//  SimpleTable3
//
//  Created by Rickie Li on 12-10-11.
//  Copyright (c) 2012年 EntLib.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleTableViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@end

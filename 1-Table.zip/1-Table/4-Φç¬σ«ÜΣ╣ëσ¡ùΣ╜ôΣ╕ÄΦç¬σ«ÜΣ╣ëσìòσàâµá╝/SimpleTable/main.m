//
//  main.m
//  SimpleTable
//
//  Created by botao Li on 12-7-15.
//  Copyright (c) 2012年 EntLib.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SimpleTableAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SimpleTableAppDelegate class]));
    }
}

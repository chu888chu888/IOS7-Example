//
//  SimpleTableViewController.h
//  SimpleTable
//
//  Created by botao Li on 12-7-15.
//  Copyright (c) 2012年 EntLib.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleTableViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@end

XHSocial
========

类似Vine的登录界面，后续加入更多组件，比如：获取好友列表、赞、个人资料等功能（注意：附带后台服务器PHP语言写的代码），希望能帮到你们


如下图:


![image](https://github.com/JackTeam/XHSocial/raw/master/Screenshots/login.png)



## License

中文:      XHSocial 是在MIT协议下使用的，可以在LICENSE文件里面找到相关的使用协议信息.

English:   XHSocial is acailable under the MIT license, see the LICENSE file for more information.


=======================
## 须知       
中文：如果您在您的项目中使用开源组件,请给我们发[电子邮件](mailto:xhzengAIB@gmail.com?subject=From%20GitHub%20XHSocial)告诉我们您的应用程序的名称,否则后果自负。         

## Instructions
         
English：If you use open source components in your project, please [Email us](mailto:xhzengAIB@gmail.com?subject=From%20GitHub%20XHSocial) to tell us the name of your application, otherwise the consequence is proud.

XHLogin
=======

一些登录组件，方便做登录页面，但是重用性比较低，但是界面效果还是过得去的

如下图:


![image](https://github.com/JackTeam/XHLogin/raw/master/Screenshots/XHLoginViewController1.png)

![image](https://github.com/JackTeam/XHLogin/raw/master/Screenshots/XHLoginViewController2.png)

![image](https://github.com/JackTeam/XHLogin/raw/master/Screenshots/XHLoginViewController3.png)

![image](https://github.com/JackTeam/XHLogin/raw/master/Screenshots/XHLoginViewController4.png)



## License

中文:      XHLogin 是在MIT协议下使用的，可以在LICENSE文件里面找到相关的使用协议信息.

English:   XHLogin is acailable under the MIT license, see the LICENSE file for more information.



=======================
## 须知       
中文：如果您在您的项目中使用开源组件,请给我们发[电子邮件](mailto:xhzengAIB@gmail.com?subject=From%20GitHub%20XHLogin)告诉我们您的应用程序的名称,否则后果自负。         

## Instructions
         
English：If you use open source components in your project, please [Email us](mailto:xhzengAIB@gmail.com?subject=From%20GitHub%20XHLogin) to tell us the name of your application, otherwise the consequence is proud.


        
